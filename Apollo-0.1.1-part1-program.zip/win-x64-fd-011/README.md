# Apollo 桌宠

Windows 离线桌宠。角色仍是原来的 Apollo C，没有另画角色，也没有把弓和天鹅那张底图接进播放。没有聊天、成长、网络或付费接口。

## 现在会动的部分

这一版是 **0.1.1**，画面换成审查通过的 v4 帧。v2 帧已从程序和发布包里去掉。画布仍是 **320×512** 的 RGBA 直通 alpha PNG。待机 48 帧，循环。摸头 48 帧，播放一次后回到待机。清单写 `fps: 24`，每一帧只有 `path`。加载器按累计取整生成 41 或 42 毫秒，48 帧合计 2000 毫秒。

v4 是单层连续位移，没有头身切口。眼睛保持睁开，没有眨眼。头、光环和头发是同一个整体。头枢轴在画布 (156, 198)，脚底锚点是 (158, 483)。举起和放下没有动作帧：窗口可以拖动，缺帧时显示待机第一帧。角色窗口上没有文字，帧里也没有底色或标题。

默认可见高度仍是 **165 DIP**，对应不透明身体约 476 像素，画布上下留着透明边。这是逻辑 DIP，不是固定物理像素：96 DPI 下 165 DIP 约 165 像素，144 DPI（150%）约 247.5 像素，192 DPI（200%）约 330 像素。滚轮和托盘把这个高度限制在 100–300 DIP，缩放时脚点留在原地。

## 在 Windows 上运行

系统：Windows 10 版本 1809 或更新，64 位。

先安装 **.NET 10 Desktop Runtime 10.0.15，Windows x64**。本仓库用 SDK 10.0.404 编译。发布目录里的 `Apollo.DesktopPet.runtimeconfig.json` 写的是 `Microsoft.NETCore.App` 10.0.0 和 `Microsoft.WindowsDesktop.App` 10.0.0。请安装 10.0.15 这一版桌面运行时。程序不会下载或安装它，也没有在 Windows 上跑过更早的 10.0 补丁。

审查用的包是依赖上述运行时的 win-x64 发布，版本 0.1.1，不是自包含包。包里有 `Microsoft.Windows.SDK.NET.dll`。本环境没有打开这个窗口。

本环境是 Linux，没有 Wine，也没有 Windows 桌面运行时。这里的测试和编译不能说明 `Apollo.DesktopPet.exe` 已经在某一台 Windows 电脑上打开过窗口。

从源码（需要 .NET 10 SDK；只有 Windows 能打开窗口）：

```bash
dotnet test Apollo.DesktopPet.slnx -c Release --nologo
dotnet run --project src/Apollo.Host.Wpf/Apollo.Host.Wpf.csproj -c Release
```

依赖运行时的发布：

```bash
dotnet publish src/Apollo.Host.Wpf/Apollo.Host.Wpf.csproj -c Release -r win-x64 --self-contained false -o artifacts/win-x64-fd --nologo
```

## 包

源帧 zip SHA-256：`317dc67d00a1bf05995032ae76a7a3438a434f865d91a72c6423109cfde64267`

这次要看的包是 `Apollo.DesktopPet-0.1.1-win-x64-framework-dependent.zip`。字节数和 SHA-256 写在旁边的 `sha256.txt`。旧的 0.1.0 包仍留在持久目录，没有删掉。源码里的 `assets/visual/reference/` 仍保留旧切图，发布包不带它们，播放也不使用它们。v2 动作帧不在这个包里。

## 还没有的

举起、放下没有姿势帧。没有眨眼，没有独立头发。Windows 界面检查在 `docs/windows-gui-checks.md`，全部仍是未执行。
