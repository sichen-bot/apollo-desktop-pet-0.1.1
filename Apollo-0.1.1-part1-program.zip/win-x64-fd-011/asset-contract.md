# 视觉资产契约

清单路径：`assets/visual/manifest.json`

路径都相对清单所在目录，只用正斜杠。不允许绝对路径，也不允许 `..`。帧和占位图都必须是 `.png`。其他扩展名会当作缺失，不会被当成动画。

## 片段 id

固定四个，区分大小写：

- `idle`：待机。当前 48 帧，循环，`fps` 24
- `headpat`：摸头。当前 48 帧，不循环，播完回待机
- `lift`：托起。没有帧
- `drop`：放下。没有帧

## 何时算「已完成的动画」

同时满足才算：

1. 该片段 `complete` 为 true
2. `frames` 至少有一帧
3. 每一帧都是清单目录内真实存在的 PNG

缺任何一帧，整个片段都回到占位图，`IsFinishedAnimation` 为 false。占位对象上的 `isFinishedAnimation` 会被忽略。占位图缺失或清单损坏时，宿主改画一个小标记，没有状态面板。

## 当前画面

占位图是 `clips/idle/0000.png`，和待机第一帧、摸头第一帧是同一份像素。画布 `pixelWidth` 320、`pixelHeight` 512，`anchor` 只能是 `root`。`rootX` / `rootY` 是脚底锚点。`content` 是不透明身体的矩形；设置里的高度按这个矩形的高度换算，不按整张画布。

没有 `durationMs` 时，片段上的 `fps` 用累计取整生成每帧时长，避免 41.666 毫秒逐帧截断后漂离 2 秒。写了 `durationMs` 的帧仍用那个值。没有 `fps` 也没有 `durationMs` 时，退回片段的 `frameDurationMs`，默认 100。

摸头区域：

```json
{ "x": 0.140625, "y": 0.017578125, "width": 0.634375, "height": 0.375 }
```

`assets/visual/reference/` 里的旧概念图和旧切图只留在源码树，不进入发布包，也不再当占位图。分层失败的旧遮罩不参与播放。

## 帧对象

```json
{ "path": "clips/headpat/0000.png" }
```

`durationMs` 小于 1 会按 1 毫秒处理。`loop` 为 false 且帧完整时，播完停在最后一帧，然后手势回到待机。没有帧的托起和放下仍用 900 毫秒和 600 毫秒的占位计时，画面停在待机第一帧。

没写到的片段会补成空的未完成片段。
